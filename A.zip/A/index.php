<?php
	$no=$_POST["no"];#馬上把no抓下來
	$u_account = stripslashes(trim($_POST['u_account']));
	$u_pwd = stripslashes(trim($_POST['u_pwd']));
	$u_name = stripslashes(trim($_POST['u_name']));
	$u_email = stripslashes(trim($_POST['u_email']));
	$u_phone = stripslashes(trim($_POST['u_phone']));
	$link=mysqli_connect("127.0.0.1","root","123456","a");
	$update="UPDATE user SET u_name='$u_name' , u_account='$u_account',u_pwd='$u_pwd',u_email='$u_pwd',u_phone='$u_phone'
	WHERE u_id=".$no;
	mysqli_query($link,$update);
?>
<html>
	<head>
		<title>
			index
		</title>
	</head>
	<body>
		<body bgcolor="#D4FFFF">
		<center><b><font size="3" color=#FFA600>
		<?php
			session_start();
			$no=$_SESSION['u_id'];
			mysqli_connect("127.0.0.1","root","123456","a") ;
			$link=mysqli_connect("127.0.0.1","root","123456","a");#連線
			// echo $read="SELECT * FROM user WHERE u_id =".$_SESSION['u_id'] ;
			// echo $readresult=mysqli_query($link,$read);#連線做此動作
			// $result=mysqli_fetch_array($readresult);#將資料存入$rows
			// echo ".$result[1]";
			$read="SELECT * FROM user WHERE u_id=".$no;
			$readresult=mysqli_query($link,$read);
			$result=mysqli_fetch_array($readresult);

			#echo "<form action='class4_updateresult.php' method='post'>";#將表格資料傳給updateresult
			echo $result[1];
			echo "歡迎回來";
			echo "<br>";
			echo "您的上次登入時間為:";
			echo $result[7];
			echo "<br>";
			echo "登入次數為:";
			echo $result[6];
			echo "<br>";
		?>
		<a href="profile.php">
		~profile~</a>

	<body>
<html>		