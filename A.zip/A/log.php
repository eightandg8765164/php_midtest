<html>
	<head>
		<title>
			登入
		</title>
	</head>
	<body>
		<body bgcolor="#D4FFFF">
	
		<center>
		<br>
		<b><font size='5' color='#4F4FFF'>
		<br>
		．．．登入．．．
		<br><br>
		<font color="#A3A3FF">
		<form action="verify.php" method="post">
			◆&nbsp;帳號&nbsp;&nbsp;&nbsp;<input type="text" size=15 name='u_account'><br><br>

			◆&nbsp;密碼&nbsp;&nbsp;&nbsp;<input type="password" size=15 name='u_pwd'><br><br>
			<input type="reset" value='reset'>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input type='submit' value='login'>
			
		</form>
		<a href="reg.php">..註冊..</a>
	</body>
</html>