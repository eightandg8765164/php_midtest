<?php
	ini_set('date.timezone','Asia/Taipei');#設定時區
	$nowTime=date('ymdHis');
	$link=mysqli_connect("127.0.0.1","root","123456","a");
	$u_account = stripslashes(trim($_POST['u_account']));
	$u_pwd = stripslashes(trim($_POST['u_pwd']));
	$u_name = stripslashes(trim($_POST['u_name']));
	$u_email = stripslashes(trim($_POST['u_email']));
	$u_phone = stripslashes(trim($_POST['u_phone']));

	$query = "SELECT u_email FROM user where u_email='$u_email'";
	mysqli_query($link,$query);
	
	$num = mysqli_num_rows(mysqli_query($link,$query));
	if($num==1)
	{ 
	    echo '這個信箱已經註冊過囉！<br />三秒後跳回上一頁'; 
	    header('refresh:3;url=reg.php'); 
	}
	else
	{
		session_start();
		$sql = "INSERT INTO user (u_account,u_pwd,u_name,u_email,u_phone,u_loginnum,u_lastlogintime) VALUES ('$u_account','$u_pwd','$u_name','$u_email','$u_phone','1','$nowTime')";
		mysqli_query($link,$sql);
		$_SESSION['u_id']=$u_account;
		echo '註冊成功！<br />三秒後返回登入畫面';
		header('refresh:3;url=log.php'); 
	}
