<html>
	<head>
		<title>
			登入失敗
		</title>
	</head>
	<body>
		<body bgcolor="#D4FFFF">
	
		<center>
		<br>
		<b><font size='5' color='#4F4FFF'>
		<br><br>
		<?php
			ini_set('date.timezone','Asia/Taipei');#設定時區
			$nowTime=date('ymdHis');
			session_start();
			$u_account=$_POST["u_account"];
			$u_pwd=$_POST["u_pwd"];
			$link=mysqli_connect("127.0.0.1","root","123456","a");#連線
			$read="SELECT * FROM user WHERE u_account='$u_account' AND u_pwd='$u_pwd'";#檢查是否有此帳號密碼
			$readresult=mysqli_query($link,$read);#連線做此動作
			$rows=mysqli_fetch_array($readresult);#將資料存入$rows


			if($rows!=NULL)
			{	
				
				$_SESSION['u_id']=$rows[0];
				$loginnum=$rows[6]+1;
				$update="UPDATE user SET u_loginnum='$loginnum' WHERE u_id=".$rows[0];
				mysqli_query($link,$update);
				$update="UPDATE user SET u_lastlogintime='$nowTime' WHERE u_id=".$rows[0];
				mysqli_query($link,$update);
				header('Location:index.php');
			}
			else
			{
				header('refresh:3 ; url="log.php"');
				$say="登入失敗，3秒後回到登入畫面<br><br>";
				echo $say;
				echo "<a href='log.php'>不想等待請按此</a>";
			}
		?>
	</body>
</html>