<?php
	session_start();
	$no=$_SESSION['u_id'];
	mysqli_connect("127.0.0.1","root","123456","a") ;
	$link=mysqli_connect("127.0.0.1","root","123456","a");#連線
			
	$read="SELECT * FROM user WHERE u_id=".$no;
	$readresult=mysqli_query($link,$read);
	$result=mysqli_fetch_array($readresult);

	
	
	

	echo "<form action='index.php' method='post'>";#將表格資料傳給updateresult
	echo "編號:".$result[0]."<br>";
	echo "<input type='hidden' name='no' value='".$result[0]."'>";#再將result[0]代入變數no，讓updateresult知道要改哪一筆
	echo "使用者名稱:<input type='text' name='u_name' value='".$result[1]."'><br>";
	echo "使用者帳號:<input type='text' name='u_account' value='".$result[2]."'><br>";#將資料存入upwd，初始值為一開始的result[2]
	echo "使用者密碼:<input type='text' name='u_pwd' value='".$result[3]."'><br>";
	echo "使用者email:<input type='text' name='u_email' value='".$result[4]."'><br>";
	echo "使用者電話:<input type='text' name='u_phone' value='".$result[5]."'><br>";

	echo "<input type='submit' value='更新'>";
	echo "<input type='reset'>";
	echo "</form>";
	#class5
	mysqli_free_result($readresult);
	mysqli_close($link);
?>
<a href="checkdel.php">
~刪除~</a>
