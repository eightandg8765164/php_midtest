<html>
	<head>
		<meta charset="utf-8">
		<title>註冊會員</title>
	</head>
		<center><div id="content">
		<br>
		<br>
		<body bgcolor="#D4FFFF">
		<form name="submit" method="post" action="reg_test.php">
			<center><div class="input-group">
			
			<font size="5" color=#A3A3FF><b>
			---------註冊會員---------<br><br>
			<font size="4" color=#4F4FFF>
			帳號：<input type="text" size=8 name="u_account">
			密碼：<input type="text" size=8 name="u_pwd"><br>
			姓名：<input type="text" size=8 name="u_name">
			email：<input type="text" size=8 name="u_email">
			電話：<input type="text" size=8 name="u_phone">
			
		
		<br/>
		<input type="reset" value="清除資料">　　　　
		<a href="reg_test.php">
		<input type="submit" value="送出資料"></a>
		</form>
	</body>
</html>