<?php
	session_start();
	$no=$_SESSION['u_id'];
	$link=mysqli_connect("127.0.0.1","root","123456","a");
	$del="DELETE FROM user WHERE u_id=".$no;#將user集合中欄位id=變數no的值的資料刪除
	mysqli_query($link,$del);
?>