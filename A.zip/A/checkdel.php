<a href="del.php">
確定刪除!<br><br>
</a>
<a href="profile.php">
返回</a>