<form action="index.php"  method="post">
請輸入名稱：<input type="text" size=8 name="name">
請輸入網址路徑：<input type="text" size=20 name="url">
<input type="reset" value="清除資料">　　　　
		<a href="index.php">
		<input type="submit" value="送出資料"></a>
</form>
