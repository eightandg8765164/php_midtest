-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- 主機: localhost
-- 產生時間： 2016-04-14 04:08:35
-- 伺服器版本: 5.7.10-log
-- PHP 版本： 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `c`
--

-- --------------------------------------------------------

--
-- 資料表結構 `uploadurl`
--

CREATE TABLE `uploadurl` (
  `name` varchar(50) NOT NULL,
  `url` varchar(100) NOT NULL,
  `short_url` varchar(100) NOT NULL,
  `upload_time` datetime(6) NOT NULL,
  `see_time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 資料表的匯出資料 `uploadurl`
--

INSERT INTO `uploadurl` (`name`, `url`, `short_url`, `upload_time`, `see_time`) VALUES
('123', 'http://www.wibibi.com/info.php?tid=372', 'http://tinyurl.com/hhp23g5', '2016-04-14 12:01:04.000000', ''),
('123', 'http://www.wibibi.com/info.php?tid=372', 'http://tinyurl.com/hhp23g5', '2016-04-14 12:01:48.000000', ''),
('123', 'http://www.wibibi.com/info.php?tid=372', 'http://tinyurl.com/hhp23g5', '2016-04-14 12:07:08.000000', ''),
('123', 'http://www.wibibi.com/info.php?tid=372', 'http://tinyurl.com/hhp23g5', '2016-04-14 12:07:35.000000', ''),
('123', 'http://www.wibibi.com/info.php?tid=372', 'http://tinyurl.com/hhp23g5', '2016-04-14 12:07:49.000000', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
