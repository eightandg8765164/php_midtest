<?php
ini_set('date.timezone','Asia/Taipei');#設定時區
$nowTime=date('ymdHis');
$url=$_POST["url"];
$name=$_POST["name"];
function getTinyUrl($url) 
{ 
	return file_get_contents("http://tinyurl.com/api-create.php?url=".$url); 
}
$shorturl=getTinyUrl($url);
$link=mysqli_connect("127.0.0.1","root","123456","c");
$add="INSERT INTO uploadurl (name,url,short_url,upload_time)VALUES('$name','$url','$shorturl','$nowTime')";
mysqli_query($link,$add);
$read="SELECT *FROM uploadurl";
$readresult=mysqli_query($link,$read);
echo "<table border='1'>";
while($result=mysqli_fetch_array($readresult))
{
	echo "<tr><td>".$result[1]."</td>";
	echo "<td>".$result[2]."</td>";
	echo "<td>".$result[4]."</td>";
	echo "<td>".$result[3]."</td>";
	echo "</tr>";
}


?>

